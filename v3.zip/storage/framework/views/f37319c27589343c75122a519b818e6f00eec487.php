<div class="row">
  <div class="col-12">
    <div class="card">
      <?php if(isset($card_header) && $card_header == 'true'): ?>
      <div class="card-header <?php if(isset($card_header_class)): ?> <?php echo e($card_header_class); ?> <?php endif; ?>">
        <?php echo e($card_header_content); ?>

      </div>
      <?php endif; ?>
      <div class="card-body">

        <?php if(isset($buttons)): ?>
          <div id="buttons" class="buttons <?php if(isset($buttons_class)): ?> <?php echo e($buttons_class); ?> <?php endif; ?>">
            <?php echo e($buttons); ?>

          </div>
        <?php endif; ?>
        
        <div class="table-responsive">
          <table class="table table-striped display nowrap w-100" data-scroll-y="400" id="<?php echo e($table_id); ?>">
            <thead>
              <?php echo e($table_header); ?>

            </thead>
            
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('after-style'); ?>
  <?php echo $__env->make('includes.datatables-styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-script'); ?>
  <?php echo $__env->make('includes.datatables-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script>
    $.extend(true, $.fn.dataTable.defaults, {
      columnDefs: {
        targets: '_all',
        defaultContent: '-'
      },
      stateSave: true,
      scrollX: true,
      scrollCollapse: true,
      language: {
        url: "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Indonesian.json",
      },
    });
  </script>

<?php $__env->stopPush(); ?><?php /**PATH F:\project cloud\rooming\resources\views/components/datatables.blade.php ENDPATH**/ ?>