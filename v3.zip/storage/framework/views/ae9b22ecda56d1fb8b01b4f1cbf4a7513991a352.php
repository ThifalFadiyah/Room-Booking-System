

<?php $__env->startSection('title'); ?>
  <?php if(isset($item)): ?>
    Edit Data Ruangan - ROOMING
  <?php else: ?> 
    Tambah Data Ruangan - ROOMING
  <?php endif; ?>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('header-title'); ?>
  <?php if(isset($item)): ?>
    Edit Data Ruangan
  <?php else: ?> 
    Tambah Data Ruangan
  <?php endif; ?>
<?php $__env->stopSection(); ?> 
    
<?php $__env->startSection('breadcrumbs'); ?>
  <div class="breadcrumb-item"><a href="#">Ruangan</a></div>
  <div class="breadcrumb-item"><a href="<?php echo e(route('room.index')); ?>">Data Ruangan</a></div>
  <div class="breadcrumb-item <?php if(isset($item)): ?> '' <?php else: ?> 'active' <?php endif; ?>">
    <?php if(isset($item)): ?>
      <a href="#">Edit Data Ruangan</a>
    <?php else: ?> 
      Tambah Data Ruangan 
    <?php endif; ?>
  </div>
  <?php if(isset($item)): ?>
    <div class="breadcrumb-item active"><?php echo e($item->name); ?></div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-title'); ?>
  <?php if(isset($item)): ?>
    Edit Data Ruangan
  <?php else: ?> 
    Tambah Data Ruangan
  <?php endif; ?>
<?php $__env->stopSection(); ?> 
    
<?php $__env->startSection('section-lead'); ?>
  Silakan isi form di bawah ini untuk <?php if(isset($item)): ?> mengedit data <?php echo e($item->name); ?> <?php else: ?> menambah data Ruangan. <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php $__env->startComponent('components.form'); ?>

    <?php $__env->slot('row_class', 'justify-content-center'); ?>
    <?php $__env->slot('col_class', 'col-12 col-md-6'); ?>

    <?php if(isset($item)): ?>
      <?php $__env->slot('form_method', 'POST'); ?>
      <?php $__env->slot('method', 'PUT'); ?>
      <?php $__env->slot('form_action', 'room.update'); ?>
      <?php $__env->slot('update_id', $item->id); ?>
    <?php else: ?> 
      <?php $__env->slot('form_method', 'POST'); ?>
      <?php $__env->slot('form_action', 'room.store'); ?>
    <?php endif; ?>

    <?php $__env->slot('is_form_with_file', 'true'); ?>

    <?php $__env->slot('input_form'); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Nama'); ?>
          <?php $__env->slot('input_type', 'text'); ?>
          <?php $__env->slot('input_name', 'name'); ?>
          <?php if(isset($item->name)): ?>
            <?php $__env->slot('input_value'); ?>
              <?php echo e($item->name); ?>

            <?php $__env->endSlot(); ?> 
          <?php endif; ?>
          <?php if(isset($item)): ?>
            <?php $__env->slot('other_attributes', 'disabled'); ?>
          <?php endif; ?>
          <?php if(empty($item)): ?>
            <?php $__env->slot('form_group_class', 'required'); ?>
            <?php $__env->slot('other_attributes', 'required autofocus'); ?>
          <?php endif; ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Deskripsi'); ?>
          <?php $__env->slot('input_type', 'text'); ?>
          <?php $__env->slot('input_name', 'description'); ?>
          <?php if(isset($item->description)): ?>
            <?php $__env->slot('input_value'); ?>
              <?php echo e($item->description); ?>

            <?php $__env->endSlot(); ?> 
          <?php endif; ?>
          <?php if(isset($item)): ?>
            <?php $__env->slot('other_attributes', 'autofocus'); ?>
          <?php endif; ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Kapasitas'); ?>
          <?php $__env->slot('input_type', 'number'); ?>
          <?php $__env->slot('input_name', 'capacity'); ?>
          <?php if(isset($item->capacity)): ?>
            <?php $__env->slot('input_value'); ?>
              <?php echo e($item->capacity); ?>

            <?php $__env->endSlot(); ?> 
          <?php endif; ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Foto'); ?>
          <?php $__env->slot('input_type', 'file'); ?>
          <?php $__env->slot('input_name', 'photo'); ?>
          <?php if(isset($item)): ?>
            <?php $__env->slot('help_text', 'Tidak perlu input foto jika tidak ingin mengeditnya'); ?>
          <?php endif; ?> 
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <?php $__env->endSlot(); ?>

    <?php $__env->slot('card_footer', 'true'); ?>
    <?php $__env->slot('card_footer_class', 'text-right'); ?>
    <?php $__env->slot('card_footer_content'); ?>
      <?php echo $__env->make('includes.save-cancel-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?> 

  <?php if (isset($__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb)): ?>
<?php $component = $__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb; ?>
<?php unset($__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project cloud\rooming\resources\views/pages/admin/room/edit_or_create.blade.php ENDPATH**/ ?>