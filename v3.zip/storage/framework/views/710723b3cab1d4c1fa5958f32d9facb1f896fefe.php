<?php $__env->startPush('after-style'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('lightbox/dist/ekko-lightbox.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-script'); ?>
  <script src="<?php echo e(asset('lightbox/dist/ekko-lightbox.min.js')); ?>"></script>    
<?php $__env->stopPush(); ?>
<?php /**PATH F:\project cloud\rooming\resources\views/includes/lightbox.blade.php ENDPATH**/ ?>