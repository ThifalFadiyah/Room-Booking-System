<div class="card card-statistic-1">
  <div class="card-icon <?php if(isset($bg_color)): ?> <?php echo e($bg_color); ?> <?php endif; ?>">
    <i class="<?php if(isset($icon)): ?> <?php echo e($icon); ?> <?php endif; ?>"></i>
  </div>
  <div class="card-wrap">
    <div class="card-header">
      <h4><?php if(isset($title)): ?> <?php echo e($title); ?> <?php endif; ?></h4>
    </div>
    <div class="card-body">
      <?php if(isset($value)): ?> <?php echo e($value); ?> <?php endif; ?>
    </div>
  </div>
</div><?php /**PATH F:\project cloud\rooming\resources\views/components/statistic-card.blade.php ENDPATH**/ ?>