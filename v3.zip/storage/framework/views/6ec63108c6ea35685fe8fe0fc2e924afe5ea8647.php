<?php if($input_type != 'hidden'): ?>

<?php if(isset($form_row) && $form_row == 'open'): ?>
<div class="form-row">
<?php endif; ?>

  <div class="form-group <?php if(isset($form_group_class)): ?> <?php echo e($form_group_class); ?> <?php endif; ?>">

    <label class="input-label"><?php if(isset($input_label)): ?><?php echo e($input_label); ?><?php endif; ?></label>

<?php endif; ?>

  <?php if($input_type == 'text' || $input_type == 'number' || $input_type == 'password' || $input_type == 'file' || $input_type == 'hidden'): ?>

      <input type="<?php echo e($input_type); ?>" 
      <?php if(isset($input_id)): ?> <?php echo e('id='.$input_id); ?> <?php endif; ?>
      <?php if(isset($input_name)): ?> <?php echo e('name='.$input_name); ?> <?php endif; ?>
      <?php if(isset($placeholder)): ?> <?php echo e('placeholder='.$placeholder); ?> <?php endif; ?> 
      class="form-control <?php if(isset($input_classes)): ?> <?php echo e($input_classes); ?> <?php endif; ?> <?php $__errorArgs = [$input_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
      value="<?php if(isset($input_value)): ?><?php echo e($input_value); ?><?php else: ?><?php echo e(($input_type == 'password') ? '' : old($input_name)); ?><?php endif; ?>"
      <?php if(isset($other_attributes)): ?> <?php echo e($other_attributes); ?> <?php endif; ?>>
      <?php $__errorArgs = [$input_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo $__env->make('includes.error-field', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <?php if(isset($help_text)): ?>
        <small class="form-text text-muted">
          <?php echo e($help_text); ?> 
        </small>
      <?php endif; ?>

    <?php elseif($input_type == 'select'): ?>

      <select 
        <?php if(isset($input_id)): ?> <?php echo e('id='.$input_id); ?> <?php endif; ?>
        <?php if(isset($input_name)): ?> <?php echo e('name='.$input_name); ?> <?php endif; ?>
        class="form-control <?php if(isset($input_classes)): ?> <?php echo e($input_classes); ?> <?php endif; ?> <?php $__errorArgs = [$input_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
        <?php if(isset($other_attributes)): ?> <?php echo e($other_attributes); ?> <?php endif; ?>
        >
        <?php echo e($select_content); ?>

      </select>
      <?php $__errorArgs = [$input_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo $__env->make('includes.error-field', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php elseif($input_type == 'textarea'): ?>

      <textarea 
        <?php if(isset($input_id)): ?> <?php echo e('id='.$input_id); ?> <?php endif; ?>
        <?php if(isset($input_name)): ?> <?php echo e('name='.$input_name); ?> <?php endif; ?>
        class="form-control <?php if(isset($input_classes)): ?> <?php echo e($input_classes); ?> <?php endif; ?> <?php $__errorArgs = [$input_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        <?php if(isset($other_attributes)): ?> <?php echo e($other_attributes); ?> <?php endif; ?>
        ><?php if(isset($input_value)): ?><?php echo e($input_value); ?><?php else: ?><?php echo e(old($input_name)); ?><?php endif; ?></textarea>
      <?php $__errorArgs = [$input_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo $__env->make('includes.error-field', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php endif; ?>

<?php if($input_type != 'hidden'): ?>

  </div> 

<?php if(isset($form_row) && $form_row == 'close'): ?>
</div> 
<?php endif; ?>  

<?php endif; ?><?php /**PATH F:\project cloud\rooming\resources\views/components/input-field.blade.php ENDPATH**/ ?>