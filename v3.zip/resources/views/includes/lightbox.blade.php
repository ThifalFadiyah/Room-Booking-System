@push('after-style')
  <link rel="stylesheet" href="{{ asset('lightbox/dist/ekko-lightbox.css') }}">
@endpush

@push('after-script')
  <script src="{{ asset('lightbox/dist/ekko-lightbox.min.js') }}"></script>    
@endpush
