

<?php $__env->startSection('title', 'Data Ruangan - ROOMING'); ?>

<?php $__env->startSection('header-title', 'Data Ruangan'); ?>
    
<?php $__env->startSection('breadcrumbs'); ?>
  <div class="breadcrumb-item"><a href="#">Ruangan</a></div>
  <div class="breadcrumb-item active">Data Ruangan</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-title', 'Ruangan'); ?>
    
<?php $__env->startSection('section-lead'); ?>
  Berikut ini adalah daftar seluruh ruangan.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php $__env->startComponent('components.datatables'); ?>
    
    <?php $__env->slot('table_id', 'room-table'); ?>

    <?php $__env->slot('table_header'); ?>
      <tr>
        <th>#</th>
        <th>Foto</th>
        <th>Nama</th>
        <th>Deskripsi</th>
        <th>Kapasitas</th>
      </tr>
    <?php $__env->endSlot(); ?>
      
  <?php if (isset($__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20)): ?>
<?php $component = $__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20; ?>
<?php unset($__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>

  <script>
  $(document).ready(function() {
    $('#room-table').DataTable({
      processing: true,
      serverSide: true,
      ajax: '<?php echo e(route('room-list.json')); ?>',
      order: [2, 'asc'],
      columns: [
      {
        name: 'DT_RowIndex',
        data: 'DT_RowIndex',
        orderable: false, 
        searchable: false
      },
      {
        name: 'photo',
        data: 'photo',
        orderable: false, 
        searchable: false,
        render: function ( data, type, row ) {
          if(data != null) {
            return `<div class="gallery gallery-fw">`
              + `<a href="<?php echo e(asset('storage/${data}')); ?>" data-toggle="lightbox">`
                + `<img src="<?php echo e(asset('storage/${data}')); ?>" class="img-fluid" style="min-width: 80px; height: auto;">`
              + `</a>`
            + '</div>';
          } else {
            return '-'
          }
        }
      },
      {
        name: 'name',
        data: 'name',
      },
      {
        name: 'description',
        data: 'description',
      },
      {
        name: 'capacity',
        data: 'capacity',
      },
    ],
    });

    $(document).on('click', '[data-toggle="lightbox"]', function(event) {
        event.preventDefault();
        $(this).ekkoLightbox();
    });
  });

</script>

<?php echo $__env->make('includes.lightbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project cloud\rooming\resources\views/pages/user/room/index.blade.php ENDPATH**/ ?>