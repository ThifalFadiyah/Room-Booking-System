

<?php $__env->startSection('title', 'Ganti Password - ROOMING'); ?>

<?php $__env->startSection('header-title', 'Ganti Password'); ?>
    
<?php $__env->startSection('breadcrumbs'); ?>
  <div class="breadcrumb-item"><a href="#">Setting</a></div>
  <div class="breadcrumb-item active">Ganti Password</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-title', 'Ganti Password '); ?>
    
<?php $__env->startSection('section-lead'); ?>
  Silakan isi form di bawah ini untuk mengganti password.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php $__env->startComponent('components.form'); ?>
    <?php $__env->slot('row_class', 'justify-content-center'); ?>
    <?php $__env->slot('col_class', 'col-12 col-md-6'); ?>

    <?php $__env->slot('form_method', 'POST'); ?>
    <?php $__env->slot('method', 'PUT'); ?>

    <?php if(Auth::user()->role == 'USER'): ?>
      <?php $__env->slot('form_action', 'user.change-pass.update'); ?>
    <?php elseif(Auth::user()->role == 'ADMIN'): ?>
      <?php $__env->slot('form_action', 'admin.change-pass.update'); ?>
    <?php endif; ?>

    <?php $__env->slot('input_form'); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Password Sekarang'); ?>
          <?php $__env->slot('input_type', 'password'); ?>
          <?php $__env->slot('input_name', 'current_password'); ?>
          <?php $__env->slot('form_group_class', 'required'); ?>
          <?php $__env->slot('other_attributes', 'required autofocus'); ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Password Baru'); ?>
          <?php $__env->slot('input_type', 'password'); ?>
          <?php $__env->slot('input_name', 'new_password'); ?>
          <?php $__env->slot('form_group_class', 'required'); ?>
          <?php $__env->slot('other_attributes', 'required'); ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Konfirmasi Password Baru'); ?>
          <?php $__env->slot('input_type', 'password'); ?>
          <?php $__env->slot('input_name', 'new_password_confirmation'); ?>
          <?php $__env->slot('form_group_class', 'required'); ?>
          <?php $__env->slot('other_attributes', 'required'); ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <?php $__env->endSlot(); ?>

    <?php $__env->slot('card_footer', 'true'); ?>
    <?php $__env->slot('card_footer_class', 'text-right'); ?>
    <?php $__env->slot('card_footer_content'); ?>
      <?php echo $__env->make('includes.save-cancel-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?> 

  <?php if (isset($__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb)): ?>
<?php $component = $__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb; ?>
<?php unset($__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

  <?php echo $__env->make('includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project cloud\rooming\resources\views/pages/change-pass/index.blade.php ENDPATH**/ ?>