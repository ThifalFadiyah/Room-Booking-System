<div class="row <?php if(isset($row_class)): ?> <?php echo e($row_class); ?> <?php endif; ?>">
  <div class="col <?php if(isset($col_class)): ?> <?php echo e($col_class); ?> <?php endif; ?>">
    <div class="card">
      <form method='<?php echo e($form_method); ?>'
        <?php if(isset($update_id)): ?>
          action='<?php echo e(route($form_action, $update_id)); ?>'  
        <?php else: ?> 
          action='<?php echo e(route($form_action)); ?>'
        <?php endif; ?>
        
        <?php if(isset($is_form_with_file) && $is_form_with_file == 'true'): ?>
          enctype='multipart/form-data'
        <?php endif; ?>
        >

        <?php echo csrf_field(); ?>
        <?php if(isset($method)): ?> <?php echo method_field($method); ?> <?php endif; ?>

        <?php if(isset($card_header) && $card_header == 'true'): ?>
        <div class="card-header <?php if(isset($card_header_class)): ?> <?php echo e($card_header_class); ?> <?php endif; ?>">
          <?php echo e($card_header_content); ?>

        </div>
        <?php endif; ?>

        <div class="card-body">
          <?php echo e($input_form); ?>

        </div>

        <?php if(isset($card_footer) && $card_footer == 'true'): ?>
        <div class="card-footer <?php if(isset($card_footer_class)): ?> <?php echo e($card_footer_class); ?> <?php endif; ?>">
          <?php echo e($card_footer_content); ?>

        </div>
        <?php endif; ?>

      </form>
    </div>
    
  </div>
</div><?php /**PATH F:\project cloud\rooming\resources\views/components/form.blade.php ENDPATH**/ ?>