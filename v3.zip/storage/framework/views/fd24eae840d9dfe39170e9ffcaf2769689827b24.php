

<?php $__env->startSection('title'); ?>
  Buat Booking - ROOMING
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('header-title'); ?>
  Buat Booking
<?php $__env->stopSection(); ?> 
    
<?php $__env->startSection('breadcrumbs'); ?>
  <div class="breadcrumb-item"><a href="#">Transaksi</a></div>
  <div class="breadcrumb-item"><a href="<?php echo e(route('my-booking-list.index')); ?>">My Booking</a></div>
  <div class="breadcrumb-item active">
    Buat Booking
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-title'); ?>
  Buat Booking
<?php $__env->stopSection(); ?> 
    
<?php $__env->startSection('section-lead'); ?>
  Silakan isi form di bawah ini untuk membuat booking.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php $__env->startComponent('components.form'); ?>
    <?php $__env->slot('row_class', 'justify-content-center'); ?>
    <?php $__env->slot('col_class', 'col-12 col-md-6'); ?>
    
    <?php $__env->slot('form_method', 'POST'); ?>
    <?php $__env->slot('form_action', 'my-booking-list.store'); ?>

    <?php $__env->slot('input_form'); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Nama Ruangan'); ?>
          <?php $__env->slot('input_type', 'select'); ?>
          <?php $__env->slot('select_content'); ?>
            <option value="">Pilih Ruangan</option>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($room->id); ?>"
                <?php echo e(old('room_id') == $room->id ? 'selected' : ''); ?>>
                <?php echo e($room->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php $__env->endSlot(); ?>
          <?php $__env->slot('input_name', 'room_id'); ?>
          <?php $__env->slot('form_group_class', 'required'); ?>
          <?php $__env->slot('other_attributes', 'required autofocus'); ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Tanggal Booking'); ?>
          <?php $__env->slot('input_type', 'text'); ?>
          <?php $__env->slot('input_name', 'date'); ?>
          <?php $__env->slot('input_classes', 'datepicker'); ?>
          <?php $__env->slot('form_group_class', 'required'); ?>
          <?php $__env->slot('other_attributes', 'required'); ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('form_row', 'open'); ?>
          <?php $__env->slot('col', 'col-md-6'); ?>
          <?php $__env->slot('input_label', 'Waktu Mulai'); ?>
          <?php $__env->slot('input_type', 'text'); ?>
          <?php $__env->slot('input_id', 'start_time'); ?>
          <?php $__env->slot('input_name', 'start_time'); ?>
          <?php $__env->slot('placeholder', 'HH:mm'); ?>
          <?php $__env->slot('input_classes', 'timepicker'); ?>
          <?php $__env->slot('form_group_class', 'col required'); ?>
          <?php $__env->slot('other_attributes', 'required'); ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('form_row', 'close'); ?>
          <?php $__env->slot('col', 'col-md-6'); ?>
          <?php $__env->slot('input_label', 'Waktu Selesai'); ?>
          <?php $__env->slot('input_type', 'text'); ?>
          <?php $__env->slot('input_id', 'end_time'); ?>
          <?php $__env->slot('input_name', 'end_time'); ?>
          <?php $__env->slot('placeholder', 'HH:mm'); ?>
          <?php $__env->slot('input_classes', 'timepicker'); ?>
          <?php $__env->slot('form_group_class', 'col required'); ?>
          <?php $__env->slot('other_attributes', 'required'); ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

      <?php $__env->startComponent('components.input-field'); ?>
          <?php $__env->slot('input_label', 'Keperluan'); ?>
          <?php $__env->slot('input_type', 'text'); ?>
          <?php $__env->slot('input_name', 'purpose'); ?>
          <?php $__env->slot('form_group_class', 'required'); ?>
          <?php $__env->slot('other_attributes', 'required'); ?>
      <?php if (isset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde)): ?>
<?php $component = $__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde; ?>
<?php unset($__componentOriginal100817f63f16f40557c7c156030f06a9dbc76dde); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <?php $__env->endSlot(); ?>

    <?php $__env->slot('card_footer', 'true'); ?>
    <?php $__env->slot('card_footer_class', 'text-right'); ?>
    <?php $__env->slot('card_footer_content'); ?>
      <?php echo $__env->make('includes.save-cancel-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?> 

  <?php if (isset($__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb)): ?>
<?php $component = $__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb; ?>
<?php unset($__componentOriginal1afc7111ef84294e4f7140e713d7c9240922e4eb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-style'); ?>
  
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-script'); ?>
  
  <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
  
<?php $__env->stopPush(); ?>

<?php echo $__env->make('includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project cloud\rooming\resources\views/pages/user/my-booking-list/create.blade.php ENDPATH**/ ?>