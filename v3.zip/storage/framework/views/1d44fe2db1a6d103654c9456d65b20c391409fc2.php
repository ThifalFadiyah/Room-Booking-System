

<?php $__env->startSection('title', 'Data User - ROOMING'); ?>

<?php $__env->startSection('header-title', 'Data User'); ?>
    
<?php $__env->startSection('breadcrumbs'); ?>
  <div class="breadcrumb-item"><a href="#">User</a></div>
  <div class="breadcrumb-item active">Data User</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section-title', 'User'); ?>
    
<?php $__env->startSection('section-lead'); ?>
  Berikut ini adalah daftar seluruh user yang ada.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php $__env->startComponent('components.datatables'); ?>

    <?php $__env->slot('buttons'); ?>
      <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i>&nbsp;Tambah User</a>
    <?php $__env->endSlot(); ?>
  
    <?php $__env->slot('table_id', 'user-table'); ?>

    <?php $__env->slot('table_header'); ?>
      <tr>
        <th>#</th>
        <th>Email</th>
        <th>Username</th>
        <th>Nama</th>
        <th>Deskripsi</th>
      </tr>
    <?php $__env->endSlot(); ?>
      
  <?php if (isset($__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20)): ?>
<?php $component = $__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20; ?>
<?php unset($__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>

  <script>
    $(document).ready(function() {
      $('#user-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route('user.json')); ?>',
        columns: [
            {
                name: 'DT_RowIndex',
                data: 'DT_RowIndex',
                orderable: false, 
                searchable: false
            },
            {
                name: 'email',
                data: 'email',
            },
            {
                name: 'username',
                data: 'username',
            },
            {
                name: 'name',
                data: 'name',
                render: function ( data, type, row ) {
                  var result = row.name;

                  var is_touch_device = 'ontouchstart' in window || navigator.msMaxTouchPoints;

                  if (is_touch_device) {
                    result += '<div>';
                  } else {
                    result += '<div class="table-links">';
                  }

                  result += ' <a href="user/'+row.id+'/edit"'
                  + ' class="text-primary">Edit</a>'

                  + ' <div class="bullet"></div>'

                  + ' <a href="user/'+row.id+'/change-pass"'
                  + ' class="text-primary">Ganti Password</a>'

                  + ' <div class="bullet"></div>'

                  + ' <a href="javascript:;" data-id="'+row.id+'" '
                  + ' data-title="Hapus"'
                  + ' data-body="Yakin ingin menghapus ini?"'
                  + ' class="text-danger"'
                  + ' id="delete-btn"'
                  + ' name="delete-btn">Hapus'
                  + ' </a>'
                  + '</div>';

                  return result;
                }
            },
            {
                name: 'description',
                data: 'description',
            },
        ],
        order: [1, 'asc'],
      });

      $(document).on('click', '#delete-btn', function() {
        var id    = $(this).data('id');
        var title = $(this).data('title');
        var body  = $(this).data('body');

        $('.modal-title').html(title);
        $('.modal-body').html(body);
        $('#confirm-form').attr('action', 'user/'+id);
        $('#confirm-form').attr('method', 'POST');
        $('#submit-btn').attr('class', 'btn btn-danger');
        $('#lara-method').attr('value', 'delete');
        $('#confirm-modal').modal('show');
      });
    
    });

</script>

<?php echo $__env->make('includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.confirm-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project cloud\rooming\resources\views/pages/admin/user/index.blade.php ENDPATH**/ ?>