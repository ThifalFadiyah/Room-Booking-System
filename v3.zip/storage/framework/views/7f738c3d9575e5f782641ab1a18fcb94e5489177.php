

<?php $__env->startSection('title', 'Dashboard - ROOMING'); ?>

<?php $__env->startSection('header-title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
  <div class="breadcrumb-item"><a href="#">Dashboard</a></div>
  <div class="breadcrumb-item active">Dashboard</div>
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('content'); ?>
<div class="row">

  <div class="col-lg-6 col-md-6 col-sm-12">
    <div class="card card-statistic-2">
      <div class="card-stats">
        <div class="card-stats-title">Statistik Booking
          
        </div>
        <div class="card-stats-items">
          <div class="card-stats-item">
            <div class="card-stats-item-count <?php if($booking_list_pending > 0): ?> <?php echo e('text-info'); ?> <?php endif; ?>"><?php echo e($booking_list_pending); ?></div>
            <div class="card-stats-item-label">Pending</div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($booking_list_disetujui); ?></div>
            <div class="card-stats-item-label">Disetujui</div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($booking_list_digunakan); ?></div>
            <div class="card-stats-item-label">Sedang Digunakan</div>
          </div>
        </div>
        <div class="card-stats-items">
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($booking_list_selesai); ?></div>
            <div class="card-stats-item-label">Selesai</div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($booking_list_batal); ?></div>
            <div class="card-stats-item-label">Batal</div>
          </div>
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($booking_list_ditolak); ?></div>
            <div class="card-stats-item-label">Ditolak</div>
          </div>
        </div>
        <div class="card-stats-items justify-content-center">
          <div class="card-stats-item">
            <div class="card-stats-item-count"><?php echo e($booking_list_expired); ?></div>
            <div class="card-stats-item-label">Expired</div>
          </div>
        </div>
      </div>
      <div class="card-icon shadow-primary bg-primary">
        <i class="fas fa-list"></i>
      </div>
      <div class="card-wrap">
        <div class="card-header">
          <h4>Total Permintaan Booking</h4>
        </div>
        <div class="card-body">
          <?php echo e($booking_list_all); ?>

        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-3 col-md-6 col-sm-6 col-12">    
    <?php $__env->startComponent('components.statistic-card'); ?>
      <?php $__env->slot('bg_color', 'bg-primary'); ?>
      <?php $__env->slot('icon', 'fas fa-door-open'); ?>
      <?php $__env->slot('title', 'Total Ruangan'); ?>
      <?php $__env->slot('value', $room); ?>
    <?php if (isset($__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42)): ?>
<?php $component = $__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42; ?>
<?php unset($__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
  </div>

  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
    <?php $__env->startComponent('components.statistic-card'); ?>
      <?php $__env->slot('bg_color', 'bg-primary'); ?>
      <?php $__env->slot('icon', 'fas fa-user'); ?>
      <?php $__env->slot('title', 'Total User'); ?>
      <?php $__env->slot('value', $user); ?>
    <?php if (isset($__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42)): ?>
<?php $component = $__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42; ?>
<?php unset($__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
  </div>
  
  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project cloud\rooming\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>