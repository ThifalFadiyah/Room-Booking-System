

<link rel="stylesheet" href="<?php echo e(asset('theme/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.dataTables.min.css"><?php /**PATH F:\project cloud\rooming\resources\views/includes/datatables-styles.blade.php ENDPATH**/ ?>