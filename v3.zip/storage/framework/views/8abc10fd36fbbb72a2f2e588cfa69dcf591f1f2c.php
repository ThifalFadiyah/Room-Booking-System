

<?php $__env->startSection('title', 'Dashboard - ROOMING'); ?>

<?php $__env->startSection('header-title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
  <div class="breadcrumb-item"><a href="#">Dashboard</a></div>
  <div class="breadcrumb-item active">Dashboard</div>
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('content'); ?>
<div class="row">

  <div class="col-lg-3 col-md-6 col-sm-6 col-12">    
    <?php $__env->startComponent('components.statistic-card'); ?>
      <?php $__env->slot('bg_color', 'bg-primary'); ?>
      <?php $__env->slot('icon', 'fas fa-calendar'); ?>
      <?php $__env->slot('title', 'Book Hari Ini'); ?>
      <?php $__env->slot('value', $booking_today); ?>
    <?php if (isset($__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42)): ?>
<?php $component = $__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42; ?>
<?php unset($__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
  </div>

  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
    <?php $__env->startComponent('components.statistic-card'); ?>
      <?php $__env->slot('bg_color', 'bg-success'); ?>
      <?php $__env->slot('icon', 'fas fa-calendar-alt'); ?>
      <?php $__env->slot('title', 'Book Semua'); ?>
      <?php $__env->slot('value', $booking_lifetime); ?>
    <?php if (isset($__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42)): ?>
<?php $component = $__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42; ?>
<?php unset($__componentOriginal3b1fd56d56748f82b499f9e0d6ba10df48f7ae42); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
  </div>
  
</div>

<?php $__env->startComponent('components.datatables'); ?>
    
  <?php $__env->slot('table_id', 'dashboard-booking-list-table'); ?>

  <?php $__env->slot('card_header', 'true'); ?>
  <?php $__env->slot('card_header_content'); ?>
    <h4>
      Booking hari ini
    </h4>
    <small>
      Diambil dari 3 data teratas.
    </small>
  <?php $__env->endSlot(); ?>

  <?php $__env->slot('buttons'); ?>
    <a href="<?php echo e(route('my-booking-list.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i>&nbsp;Booking</a>
  <?php $__env->endSlot(); ?>

  <?php $__env->slot('table_header'); ?>
    <tr>
      <th>#</th>
      <th>Foto</th>
      <th>Ruangan</th>
      <th>Tanggal</th>
      <th>Waktu Mulai</th>
      <th>Waktu Selesai</th>
      <th>Keperluan</th>
      <th>Status</th>
    </tr>
  <?php $__env->endSlot(); ?>
    
<?php if (isset($__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20)): ?>
<?php $component = $__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20; ?>
<?php unset($__componentOriginal9b3a2dd8ed29d33a6c963ff6acd848d07be5fd20); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>

  <script>
  $(document).ready(function() {
    $('#dashboard-booking-list-table').DataTable({
      processing: true,
      ajax: '<?php echo e(route('dashboard.booking-list')); ?>',
      order: [2, 'asc'],
      columns: [
      {
        name: 'DT_RowIndex',
        data: 'DT_RowIndex',
        orderable: false, 
        searchable: false
      },
      {
        name: 'room.photo',
        data: 'room.photo',
        orderable: false, 
        searchable: false,
        render: function ( data, type, row ) {
          if(data != null) {
            return `<div class="gallery gallery-fw">`
              + `<a href="<?php echo e(asset('storage/${data}')); ?>" data-toggle="lightbox">`
                + `<img src="<?php echo e(asset('storage/${data}')); ?>" class="img-fluid" style="min-width: 100px; height: auto;">`
              + `</a>`
            + '</div>';
          } else {
            return '-'
          }
        }
      },
      {
        name: 'room.name',
        data: 'room.name',
      },
      {
        name: 'date',
        data: 'date',
      },
      {
        name: 'start_time',
        data: 'start_time',
      },
      {
        name: 'end_time',
        data: 'end_time',
      },
      {
        name: 'purpose',
        data: 'purpose',
      },
      {
        name: 'status',
        data: 'status',
        render: function ( data, type, row ) {
          var result = `<span class="badge badge-`;

          if(data === 'PENDING') 
            result += `info`;
          else if(data === 'DISETUJUI')
            result += `primary`;
          else if(data === 'DIGUNAKAN')
            result += `primary`;
          else if(data === 'DITOLAK')
            result += `danger`;
          else if(data === 'EXPIRED')
            result += `warning`;
          else if(data === 'BATAL')
            result += `warning`;
          else if(data === 'SELESAI')
            result += `success`;

          result += `">${data}</span>`;

          return result;
        } 
      },
    ],
    });

    $(document).on('click', '[data-toggle="lightbox"]', function(event) {
        event.preventDefault();
        $(this).ekkoLightbox();
    });
  });

</script>

<?php echo $__env->make('includes.lightbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.confirm-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project cloud\rooming\resources\views/pages/user/dashboard.blade.php ENDPATH**/ ?>