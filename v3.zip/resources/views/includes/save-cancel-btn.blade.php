<button class="btn btn-primary">Simpan</button>
<a type="button" href="{{ URL::previous() }}" class="btn btn-secondary">Cancel</a>