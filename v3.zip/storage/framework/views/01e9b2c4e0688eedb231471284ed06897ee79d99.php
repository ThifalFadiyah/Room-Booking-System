<?php if(Session::has('alert-success') || Session::has('alert-failed')): ?>
    <?php $__env->startPush('after-style'); ?>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.min.css">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('after-script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.min.js"></script>
        <?php if(Session::has('alert-success')): ?>
            <script>
                iziToast.success({
                    title: 'Sukses!',
                    message: '<?php echo e(Session::get('alert-success')); ?>',
                    position: 'topRight'
                });
            </script>
        <?php else: ?>
        <script>
            iziToast.error({
                title: 'Gagal!',
                message: '<?php echo e(Session::get('alert-failed')); ?>',
                position: 'topRight'
            });
        </script>
        <?php endif; ?>
    <?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH F:\project cloud\rooming\resources\views/includes/notification.blade.php ENDPATH**/ ?>