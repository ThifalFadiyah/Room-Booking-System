<footer class="main-footer">
  <div class="footer-left">
    &copy; ROOMING 2021 
  </div>
  <div class="footer-right">
    1.0
  </div>
</footer><?php /**PATH F:\project cloud\rooming\resources\views/includes/main/footer.blade.php ENDPATH**/ ?>