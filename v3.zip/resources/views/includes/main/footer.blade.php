<footer class="main-footer">
  <div class="footer-left">
    &copy; ROOMING 2021 
  </div>
  <div class="footer-right">
    1.0
  </div>
</footer>